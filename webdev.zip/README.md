## Web

### Installation

`npm install`
Get dependencies installed

`npm run start`
Start the server process listening on port 8085.

